
package com.example.secretcalculator

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var display: TextView
    private var currentInput = "0"
    private var secretCode = "1102"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        display = findViewById(R.id.display)

        val buttons = mapOf(
            R.id.btn0 to "0", R.id.btn1 to "1", R.id.btn2 to "2",
            R.id.btn3 to "3", R.id.btn4 to "4", R.id.btn5 to "5",
            R.id.btn6 to "6", R.id.btn7 to "7", R.id.btn8 to "8",
            R.id.btn9 to "9"
        )

        for ((id, num) in buttons) {
            findViewById<Button>(id).setOnClickListener {
                if (currentInput == "0") currentInput = num else currentInput += num
                display.text = currentInput
            }
        }

        findViewById<Button>(R.id.btnEquals).setOnClickListener {
            if (currentInput == secretCode) {
                startActivity(Intent(this, LoveNotesActivity::class.java))
                currentInput = "0"
                display.text = currentInput
            }
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            currentInput = "0"
            display.text = currentInput
        }
    }
}
