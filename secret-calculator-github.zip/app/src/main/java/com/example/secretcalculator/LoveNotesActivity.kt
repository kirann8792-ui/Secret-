
package com.example.secretcalculator

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LoveNotesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_love_notes)

        val text = findViewById<TextView>(R.id.displayNote)
        text.text = "Happy one month of your marriage ❤️"
    }
}
